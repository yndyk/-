#pragma once
#define ENEMY_MAX 9
extern CHARACTER enemy[ENEMY_MAX];

void SysInitEnemy();
void InitEnemy();
void UpdetaEnemy();
void DrawEnemy();