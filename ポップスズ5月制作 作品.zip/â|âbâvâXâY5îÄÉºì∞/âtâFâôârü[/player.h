#pragma once

extern CHARACTER player;

void SysInitPlayer();
void InitPlayer();
void UpdetaPlayer();
void DrawPlayer();