#pragma once

extern CHARACTER shot;

void SysInitShot();
void InitShot();
void UpdetaShot();
void DrawShot();